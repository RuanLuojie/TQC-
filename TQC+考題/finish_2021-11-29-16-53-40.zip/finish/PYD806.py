# TODO
string = input()
char = input()

print('{} occurs {} time(s)'.format(char,string.count(char)))

"""
_ occurs _ time(s)
"""
