# TODO
string = input()
print(string.upper())
print(string.title())
